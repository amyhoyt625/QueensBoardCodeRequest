package cs3500.queensboard.player;

import cs3500.queensboard.model.Board;
import cs3500.queensboard.model.QueensBoard;
import cs3500.queensboard.strategy.Move;

/**
 *  Player Actions Interface represents the types of players that QueensBoard
 *  can have play the game. This includes the human player that can interact
 *  with the board and a computer player that uses a strategy.
 */
public interface PlayerActionsInterface {
  Move makeMove(QueensBoard board);

  boolean isComputerTurn();

  Board.Player getPlayerColor();
}
