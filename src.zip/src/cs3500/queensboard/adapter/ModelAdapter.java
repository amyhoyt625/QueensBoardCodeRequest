package cs3500.queensboard.adapter;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import cs3500.queensboard.model.Board;
import cs3500.queensboard.model.Cell;
import cs3500.queensboard.model.ReadOnlyQueensBoard;
import cs3500.queensboard.provider.model.BoardPiece;
import cs3500.queensboard.model.Card;
import cs3500.queensboard.provider.model.CardGame;
import cs3500.queensboard.provider.model.GameState;
import cs3500.queensboard.provider.model.Player;
import cs3500.queensboard.provider.model.PlayerState;
import cs3500.queensboard.provider.model.ReadOnlyQueensBloodModel;

public class ModelAdapter implements ReadOnlyQueensBloodModel {
  private final ReadOnlyQueensBoard model;

  public ModelAdapter(ReadOnlyQueensBoard model) {
    this.model = model;
  }

  @Override
  public int getWidth() {
    return model.getWidth();
  }

  @Override
  public int getHeight() {
    return model.getHeight();
  }

  @Override
  public BoardPiece getItemAt(int row, int col) {
    //try to get the Card
    Card modelCard = model.getCardAt(row, col);

    if (modelCard != null) {
      return new CardtoCardGame(
              modelCard.getName(),
              modelCard.getCost(),
              modelCard.getValue(),
              modelCard.getInfluence(),
              modelCard.getInfluenceGrid()
      );
    }

    return null; // Or return new EmptyPiece() if you want a non-null fallback
  }

  @Override
  public int getRemainingRedDeckSize() {
    return model.getRemainingDeckSize(Board.Player.RED);
  }

  @Override
  public int getRemainingBlueDeckSize() {
    return model.getRemainingDeckSize(Board.Player.BLUE);
  }

  @Override
  public GameState isGameOver() {
    if (model.getWinner().equals(Board.Player.RED)) {
      return GameState.RED_WINS;
    }
    else if (model.getWinner().equals(Board.Player.BLUE)) {
      return GameState.BLUE_WINS;
    }
    else if (model.getWinner().equals(Board.Player.NONE)) {
      return GameState.GAME_ONGOING;
    }
    else {
      return GameState.TIE;
    }
  }

  @Override
  public int redTotalScore() {
    int redTotal = 0;
    for (int r = 0; r < getHeight(); r++) {
      if (model.getRedRowScore(r) > model.getBlueRowScore(r)) {
        redTotal += model.getRedRowScore(r);
      }
    }
    return redTotal;
  }

  @Override
  public int blueTotalScore() {
    int blueTotal = 0;
    for (int r = 0; r < getHeight(); r++) {
      if (model.getBlueRowScore(r) > model.getRedRowScore(r)) {
        blueTotal += model.getRedRowScore(r);
      }
    }
    return blueTotal;
  }

  @Override
  public PlayerState getRedPlayerState() {
    return null;
  }

  @Override
  public PlayerState getBluePlayerState() {
    return null;
  }

  @Override
  public Player turn() {
    Board.Player player = model.getTurn();
    if (player.equals(Board.Player.RED)){
      return Player.RED;
    }
    else {
      return Player.BLUE;
    }
  }

  // TODO
  @Override
  // Should be taking in the interface Card, not the class
  public List<CardGame> getPlayerHand(Player player) {
    return null;
  }

  // TODO
  @Override
  // Should be taking in the interface Card, not the class
  public List<CardGame> getCurrentPlayerHand() {
    List<CardtoCardGame> hand = new ArrayList<>();
    List<cs3500.queensboard.model.Card> oldHand = model.getHand();
    for (cs3500.queensboard.model.Card card : oldHand) {
      hand.add((CardtoCardGame) card);
    }
    return null;
  }

  @Override
  public Optional<Player> getOwnerAt(int row, int col) {
    Cell currCell = model.getCell(row, col);
    Board.Player owner = currCell.getOwner();
    if (owner.equals(Board.Player.RED)) {
      return Optional.ofNullable(Player.RED);
    }
    else {
      return Optional.ofNullable(Player.BLUE);
    }
  }

  @Override
  public boolean canPlayCardAt(Player player, int cardIdx, int row, int col) {
    return false;
  }

  @Override
  public int getRowScore(Player player, int row) {
    if (player.equals(Player.RED)) {
      return model.getRedRowScore(row);
    }
    else {
      return model.getBlueRowScore(row);
    }
  }
}