package cs3500.queensboard.adapter;

import cs3500.queensboard.model.Board;
import cs3500.queensboard.model.QueensCard;
import cs3500.queensboard.provider.model.BoardPiece;
import cs3500.queensboard.provider.model.Card;
import cs3500.queensboard.provider.model.CardGame;
import cs3500.queensboard.provider.model.Player;
import cs3500.queensboard.provider.model.PlayerState;

public class CardtoCardGame extends QueensCard implements Card {

  public CardtoCardGame(String name, int cost, int value, Board.Player influence, char[][] influenceGrid) {
    super(name, cost, value, influence, influenceGrid);
  }

  @Override
  public void cardInteraction(Card card, BoardPiece[][] board, int row, int col, PlayerState playerState) {

  }

  @Override
  public boolean canPlaceCard(Card card, Player player) {
    return false;
  }

  /**
   * Helper method to convert a Player to a Board.Player
   * @param player The Player to convert
   * @return The equivalent Board.Player
   */
  private Player convertToPlayer(Board.Player player) {
    return Player.valueOf(player.toString());
  }


  @Override
  public Player getOwner() {
    Board.Player player = getInfluence();
    return convertToPlayer(player);
  }

  @Override
  public void handleInfluenceInteraction(Player owner) {
    //nothing happens
  }

  @Override
  public void switchOwner() {
    //nothing happens
  }

  @Override
  public int getDisplayValue() {
    return getValue();
  }

  @Override
  public BoardPiece copy() {
    return new CardGame(getName(), getCost(), getValue(), getInfluenceGrid(), getOwner());
  }
}
