package cs3500.queensboard.adapter;

import java.util.List;

import cs3500.queensboard.controller.QueensBoardControllerInterface;
import cs3500.queensboard.provider.controller.ViewListener;
import cs3500.queensboard.provider.model.CardGame;
import cs3500.queensboard.provider.model.Player;
import cs3500.queensboard.provider.model.ReadOnlyQueensBloodModel;
import cs3500.queensboard.provider.view.QueensBloodViewGUITraditional;
import cs3500.queensboard.view.QueensBoardGUIView;

public class ViewAdapter extends QueensBloodViewGUITraditional implements QueensBoardGUIView {

  private ReadOnlyQueensBloodModel model;

  /**
   * Constructs the GUI and initializes the visuals of the game within the given model.
   *
   * @param model  read-only model of the QueensBlood board game.
   * @param player
   * @throws IllegalArgumentException If model or player given are null.
   */
  public ViewAdapter(ReadOnlyQueensBloodModel model, Player player) {
    super(model, player);
  }

  @Override
  public void clearHighlights() {
    this.clearHighlights();
  }

  @Override
  public void disableInput() {

  }

  //TODO check if this works
  @Override
  public void addObserver(QueensBoardControllerInterface obs) {
    this.addListener((ViewListener) obs);
  }

  @Override
  public void highlightCell(int row, int col) {
    this.highlightCell(row, col);
  }

  @Override
  public void highlightCard(int cardIndex) {
    this.highlightCard(cardIndex);
  }

  //cardgame --> card interface
  @Override
  public void placeCard(int row, int col, int cardIndex) {
    List<CardGame> providerHand = this.model.getCurrentPlayerHand();
    CardGame cardAtPosition = providerHand.get(cardIndex);
    this.placeCard(cardAtPosition, row, col);
  }
}