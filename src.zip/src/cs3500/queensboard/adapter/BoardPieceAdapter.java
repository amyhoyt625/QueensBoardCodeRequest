package cs3500.queensboard.adapter;

import cs3500.queensboard.model.Card;
import cs3500.queensboard.model.Cell;
import cs3500.queensboard.provider.model.BoardPiece;
import cs3500.queensboard.provider.model.Player;
import cs3500.queensboard.provider.model.PlayerState;

public class BoardPieceAdapter implements BoardPiece {
  private final Cell cell;
  private final Card card;

  public BoardPieceAdapter(Cell cell, Card card) {
    this.cell = cell;
    this.card = card;
  }

  @Override
  public void cardInteraction(cs3500.queensboard.provider.model.Card card, BoardPiece[][] board, int row, int col, PlayerState playerState) {

  }

  @Override
  public boolean canPlaceCard(cs3500.queensboard.provider.model.Card card, Player player) {
    return false;
  }

  @Override
  public int getValue() {
    return 0;
  }

  @Override
  public Player getOwner() {
    return null;
  }

  @Override
  public void handleInfluenceInteraction(Player owner) {

  }

  @Override
  public void switchOwner() {

  }

  @Override
  public int getDisplayValue() {
    return 0;
  }

  @Override
  public BoardPiece copy() {
    return null;
  }
}
