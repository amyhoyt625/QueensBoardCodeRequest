package cs3500.queensboard.view;

import cs3500.queensboard.controller.QueensBoardController;
import cs3500.queensboard.controller.QueensBoardControllerInterface;


/**
 * This interface marks the GUI Rendering of the current game
 * state of the gameboard.
 * This interface is implemented by QueensBoardViewClass in order to
 * create an instance of the game view.
 */
public interface QueensBoardGUIView {


  void clearHighlights();

  void disableInput();

  void repaint();

  /**
   * Adds an observer (controller) to the list of observers.
   *
   * @param obs the observer (controller) being added
   */
  void addObserver(QueensBoardControllerInterface obs);

  /**
   * Highlights the selected cell on the board by determining its position on the board,
   * and repainting the panel with the yellow outline.
   * @param row The row index of the cell to highlight.
   * @param col The column index of the cell to highlight.
   */
  void highlightCell(int row, int col);

  /**
   * Highlights the selected card on the board by determining its index within the player hand
   * and repainting the panel with the yellow outline.
   *
   * @param cardIndex The index of the card in the player hand to highlight
   */
  void highlightCard(int cardIndex);

  //physically places card on board
  void placeCard(int row, int col, int cardIndex);
}
